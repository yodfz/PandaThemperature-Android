package com.example.pandatemperature.data.device.parser

import com.example.pandatemperature.data.model.TemperatureRecord
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * 历史数据解析器
 * 支持两种格式：
 * - 新格式（12字节）：timestamp(4) + temp(2) + hum(2) + pressure(4)
 * - 老格式（8字节）：timestamp(4) + temp(2) + hum(2)
 * 
 * @param deviceId 设备 MAC 地址，用于创建记录
 */
class HistoryDataParser(private val deviceId: String) : DataParser<List<TemperatureRecord>> {
    
    companion object {
        const val RECORD_SIZE_V2 = 12  // 新格式：含气压
        const val RECORD_SIZE_V1 = 8   // 老格式：无气压
    }
    
    override val expectedMinLength: Int = RECORD_SIZE_V1  // 最小需要一条老格式记录
    
    override fun canParse(data: ByteArray): Boolean {
        return data.size >= expectedMinLength
    }
    
    override fun parse(data: ByteArray): List<TemperatureRecord>? {
        if (!canParse(data)) return null
        
        return try {
            val records = mutableListOf<TemperatureRecord>()
            val buffer = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
            var offset = 0
            
            while (true) {
                // 优先尝试新格式（12字节）
                if (offset + RECORD_SIZE_V2 <= data.size) {
                    val record = parseRecordV2(buffer, offset)
                    if (record != null) {
                        records.add(record)
                        offset += RECORD_SIZE_V2
                        continue
                    }
                }
                
                // 尝试老格式（8字节）
                if (offset + RECORD_SIZE_V1 <= data.size) {
                    val record = parseRecordV1(buffer, offset)
                    if (record != null) {
                        records.add(record)
                        offset += RECORD_SIZE_V1
                        continue
                    }
                }
                
                // 数据不足，退出循环
                break
            }
            
            if (records.isEmpty()) null else records
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * 解析新格式记录（12字节）
     * timestamp(4) + temp(2) + hum(2) + pressure_centihpa(4)
     */
    private fun parseRecordV2(buffer: ByteBuffer, offset: Int): TemperatureRecord? {
        return try {
            val timestamp = buffer.getInt(offset).toLong() and 0xFFFFFFFFL
            val tempRaw = buffer.getShort(offset + 4)
            val humRaw = buffer.getShort(offset + 6).toInt() and 0xFFFF
            val pressureRaw = buffer.getInt(offset + 8).toLong() and 0xFFFFFFFFL  // uint32，单位：0.01 hPa
            
            val temperature = tempRaw / 100.0f
            val humidity = humRaw / 100.0f
            val pressure = pressureRaw / 100.0f  // 转换为标准 hPa
            
            TemperatureRecord(
                timestamp = timestamp,
                temperature = temperature,
                humidity = humidity,
                pressure = pressure,
                deviceId = deviceId
            )
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * 解析老格式记录（8字节）
     * timestamp(4) + temp(2) + hum(2)
     */
    private fun parseRecordV1(buffer: ByteBuffer, offset: Int): TemperatureRecord? {
        return try {
            val timestamp = buffer.getInt(offset).toLong() and 0xFFFFFFFFL
            val tempRaw = buffer.getShort(offset + 4)
            val humRaw = buffer.getShort(offset + 6).toInt() and 0xFFFF
            
            val temperature = tempRaw / 100.0f
            val humidity = humRaw / 100.0f
            
            TemperatureRecord(
                timestamp = timestamp,
                temperature = temperature,
                humidity = humidity,
                pressure = null,  // 老格式没有气压
                deviceId = deviceId
            )
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * 判断数据包使用的格式
     * @return true 为新格式（12字节），false 为老格式（8字节）
     */
    fun detectFormat(data: ByteArray): Boolean {
        // 如果数据长度是12的倍数，优先认为是新格式
        // 如果只是8的倍数，认为是老格式
        return when {
            data.size % RECORD_SIZE_V2 == 0 -> true
            data.size % RECORD_SIZE_V1 == 0 -> false
            else -> data.size >= RECORD_SIZE_V2  // 默认尝试新格式
        }
    }
}
