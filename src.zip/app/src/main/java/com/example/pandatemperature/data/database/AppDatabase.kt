package com.example.pandatemperature.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.pandatemperature.data.database.dao.DeviceDao
import com.example.pandatemperature.data.database.dao.TemperatureRecordDao
import com.example.pandatemperature.data.model.Device
import com.example.pandatemperature.data.model.TemperatureRecord

/**
 * Room 数据库实例
 */
@Database(
    entities = [TemperatureRecord::class, Device::class],
    version = 9,  // temperature_records 添加 altitudeMeters（GPS 海拔）
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    
    abstract fun temperatureRecordDao(): TemperatureRecordDao
    abstract fun deviceDao(): DeviceDao
    
    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null
        
        /**
         * 数据库迁移：版本 5 → 6
         * 为 devices 表添加 firmwareVersion 字段
         */
        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE devices ADD COLUMN firmwareVersion INTEGER DEFAULT NULL")
            }
        }
        
        /**
         * 数据库迁移：版本 6 → 7
         * 为 temperature_records 表添加 GPS 字段（latitude, longitude）
         */
        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE temperature_records ADD COLUMN latitude REAL DEFAULT NULL")
                database.execSQL("ALTER TABLE temperature_records ADD COLUMN longitude REAL DEFAULT NULL")
            }
        }

        /**
         * 数据库迁移：版本 7 → 8
         * 为 devices 表添加 nickname 字段（设备昵称）
         */
        private val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE devices ADD COLUMN nickname TEXT DEFAULT NULL")
            }
        }
        
        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "panda_temperature_database"
                )
                    .addMigrations(MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8)
                    .fallbackToDestructiveMigration() // 迁移失败时的兜底策略
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
